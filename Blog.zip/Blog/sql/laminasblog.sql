-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2024 at 05:10 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laminasblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_path` longblob NOT NULL,
  `content` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `title`, `image_path`, `content`, `date`, `user_id`) VALUES
(29, 'Dhanushkodi – Beautiful Abandoned Town', '', 'If you are someone who’s on a constant lookout for places that are away from the city life, Dhanushkodi is one of the best places to visit in Tamil Nadu. This beach town’s grandeur and beauty make Dhanushkodi one of the best tourist places in Tamil Nadu f', '2024-01-12', 27),
(33, 'Darjeeling, West Bengal - Queen of The Himalayas', '', 'Jaw-dropping locales, mesmerising sunrises, the untouched beauty of the hills, the old-world charm of the past, and the welcoming smiles of the local people all add up to make Darjeeling one of the most beautiful hill stations in Eastern part of India.', '2024-01-11', 29),
(35, 'Srinagar, Jammu & Kashmir - The Paradise on Earth', '', 'Famously known as \'Heaven on Earth\', Srinagar is every bit the epitome of paradise on earth. As picturesque as the most stunning painting to ever be painted, Srinagar, the capital of Jammu and Kashmir, lies on the banks of the Jhelum river, and has a cool', '2024-01-04', 27),
(36, 'Shillong, Meghalaya - Scotland of the East', '', 'A beautiful city encircled by pine trees, Shillong is the capital of Meghalaya. Known as the \'Scotland of the East\', it derives its name from Lei Shyllong, an idol worshipped at the Shillong Peak. Standing as tall as 1496 meters, Shillong provides a relie', '2024-01-11', 29),
(37, 'Chennai – Cultural Centre', '', 'Being the capital of the state and home to beautiful temples, churches, and beaches, Chennai is best tourist place in Tamil Nadu that would let you have a real glimpse of South India and its lifestyle. With numerous places to visit in Chennai such as Mari', '2024-01-10', 29),
(38, 'Meghalaya: For its Spellbinding Natural Beauty', '', 'Also known as the abode of clouds, Meghalaya is a hidden gem nestled in the lap of pine-covered Khasi and Garo Hills in the Northeastern part of India. One of the most picturesque states of North East India with its innumerable waterfalls, mystic caves', '2024-01-17', 29);

-- --------------------------------------------------------

--
-- Table structure for table `cmddd`
--

CREATE TABLE `cmddd` (
  `id` int(11) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `user_id` int(11) NOT NULL,
  `album_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cmddd`
--

INSERT INTO `cmddd` (`id`, `comment`, `user_id`, `album_id`) VALUES
(21, 'good', 29, 35),
(22, 'excellent', 29, 29),
(23, 'haiiiiiiiiii', 29, 37),
(25, 'excellent blog', 27, 37),
(26, 'bad', 27, 33);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `album_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `comment` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `required` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_contents`
--

CREATE TABLE `page_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_lang_contents`
--

CREATE TABLE `page_lang_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang` varchar(2) CHARACTER SET utf32 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `page_content_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_metadata`
--

CREATE TABLE `page_metadata` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang` varchar(3) CHARACTER SET latin1 NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `page_to_contents`
--

CREATE TABLE `page_to_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `password_salt` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_salt`) VALUES
(23, 'admin', 'admin@gmail.com', 'c2542992199ba32721b0bf8a8626335ba55ed20a3ae7300795c73297c68df28fc18fa34ee10d76748d44c6b6684ce9a8e4d3b084d30ba719ea83d4eddd131d9c', 'BKQA5'),
(27, 'asha123', 'asha@gmail.com', 'c128630c7405d000266109f1c41b6da17e5593efd4c02da7a3623449a69f45bd004451b6f3ed542a8d967c8afca4245672a2a24a47530990d2a61c2b21b2c533', 'khzifB'),
(29, 'sandra', 'sandra@gmail.com', '01553fb5c3b492c5e58a8adce0133a06d2a8cde564653b3ca5d7e6967f404dc99d7a9a9e7be1642707d84ae069e9d5602143274d14ffa364808bf70e75cbb2ec', 'diMDp2W'),
(30, 'asha12344', 'asha1234@gmail.com', '663c1c30807a2310694b9d09f6aff0bc604e007dabeae8fbef37c8d99d9a372a0349abc6ae6af2da63f54decd6e83b54a973f9a645e22348fe501bb7159f6858', 'iGjcYD'),
(31, 'sandra1234', 'sandra1234@gmail.com', '115864766be70fc5567ebb8f47dadf1b419889e41a8ed369022ae5abf0efc2e511a18905312e062b7ed2f3f610527c6f7de8c06ef57d983509798abb3b590593', 'q8SA7wg'),
(36, 'ashok', 'ashok@gmail.com', '04cc9d9072b48c42c093a8996f64cbd3038da0fac99db708816e25228aba2e2147f15ea09151569f4de79210cd86753c168a4dd28dd9ffdb63a3fad0b46b008e', 'dga9QmeM'),
(37, 'sara123', 'sara123@gmail.com', 'ac30a51aa52918a86954c1ccf750b6a970151c9133b1b02a5e6a1b79d1f3ba8cd31aaf1e864e186b6cd704f2163fcb2aa42b52d2f1d5a2848a06ad5b03bb933d', 'bskN8Fe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `cmddd`
--
ALTER TABLE `cmddd`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cmddd_ibfk_1` (`user_id`),
  ADD KEY `cmddd_ibfk_2` (`album_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `album_id` (`album_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lang` (`lang`);

--
-- Indexes for table `page_metadata`
--
ALTER TABLE `page_metadata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_to_contents`
--
ALTER TABLE `page_to_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_id` (`page_id`,`content_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `cmddd`
--
ALTER TABLE `cmddd`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_contents`
--
ALTER TABLE `page_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_metadata`
--
ALTER TABLE `page_metadata`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_to_contents`
--
ALTER TABLE `page_to_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `album`
--
ALTER TABLE `album`
  ADD CONSTRAINT `album_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `cmddd`
--
ALTER TABLE `cmddd`
  ADD CONSTRAINT `cmddd_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `cmddd_ibfk_2` FOREIGN KEY (`album_id`) REFERENCES `album` (`id`) ON DELETE NO ACTION;

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
