<?php

namespace Admin\Controller;

use Admin\Form\AdminForm;
use Admin\Model\Admin;
use Admin\Model\AdminTable;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Laminas\Session;

use Laminas\EventManager\EventManagerInterface;


class AdminController extends AbstractActionController
{

    private $table;

    public function __construct(AdminTable $table)
    {
        $this->table = $table;
    }

    public function indexAction()
    {
        return new ViewModel([
            'admins' => $this->table->getAll(),
        ]);
    }
    

    public function setEventManager(EventManagerInterface $events)
    {
        parent::setEventManager($events);
        
	 $events->attach('dispatch', function ($e) {
       
            
            $userSession = new Session\Container('user');
            
            if ($userSession->details) {
                $e->getViewModel()->setVariable('user', $userSession->details);
            }
	}, 100);

    }


        public function deleteAction()
        {
            $id = (int) $this->params()->fromRoute('id', 0);
            if (!$id) {
                return $this->redirect()->toRoute('admin');
            }
    
            $request = $this->getRequest();
            if ($request->isPost()) {
                $del = $request->getPost('del', 'No');
    
                if ($del == 'Yes') {
                    $id = (int) $request->getPost('id');
                    $this->table->deleteAlbum($id);
                }
    
                // Redirect to list of albums
                return $this->redirect()->toRoute('admin');
            }
    
            return [
                'id'    => $id,
                'admin' => $this->table->getAlbum($id),
            ];
        }

        public function logoutAction()
        {
            $session = new Session\Container('admin');
            $session->getManager()->destroy();
            $this->redirect()->toRoute('home');
        }
}