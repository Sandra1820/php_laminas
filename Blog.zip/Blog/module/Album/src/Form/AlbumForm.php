<?php

namespace Album\Form;

use Laminas\Form\Form;
use Laminas\Form\Element;

class AlbumForm extends Form
{
    public function __construct($name = null)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('album');

        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);
        $this->add([
            'name' => 'date',
            'type' => Element\Date::class,
            'options' => [
                'label' => 'Date',
            ],
        ]);
        $this->add([
            'name' => 'title',
            'type' => Element\Text::class,
            'options' => [
                'label' => 'Title',
            ],
        ]);
        $this->add([
            'name' => 'content',
            'type' => Element\Textarea::class,
            'options' => [
                'label' => 'Content',
            ],
        ]);
        // $this->add([
        //     'name' => 'image',
        //     'type' => Element\File::class,
        //     'options' => [
        //         'label' => 'image Upload',
        //     ],
        // ]);
        $this->add([
            'name' => 'submit',
            'type' => Element\Submit::class,
            'attributes' => [
                'value' => 'Submit',
                'id'    => 'submitbutton',
            ],
        ]);
    }
}