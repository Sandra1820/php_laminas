<?php

namespace Album\Model;

use Laminas\Db\TableGateway\TableGateway;
use RuntimeException;
use Laminas\Db\TableGateway\TableGatewayInterface;
use Laminas\Session;
use Laminas\Db\sql\Select;
class AlbumTable
{
    private $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll()
    {
        return $this->tableGateway->select();
    }

    public function getAll()
    {
        $userSession = new Session\Container('user');
        $userid= $userSession->details->getId();

        return $this->tableGateway->select(function(Select $select )use($userid){
            $select->join('users','album.user_id = users.id',[])->where(['users.id'=>$userid]);
        });
    }


    public function getAlbum($id)
    {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(['id' => $id]);
        $row = $rowset->current();
        if (! $row) {
            throw new RuntimeException(
                sprintf('Could not find row with identifier %d',$id)
            );
        }

        return $row;
    }

    public function saveAlbum(Album $album)
    {
        $userSession = new Session\Container('user');
        $userid= $userSession->details->getId();
        $data = [
            'date'  =>$album->date,
            'title'  => $album->title,
            'content'=>$album->content,
            'user_id'=>$userid
        ];

        $id = (int) $album->id;

        if ($id === 0) {
            $this->tableGateway->insert($data);
            return;
        }

        try {
            $this->getAlbum($id);
        } catch (RuntimeException $e) {
            throw new RuntimeException(sprintf('Cannot update album with identifier %d; does not exist',$id)
        );
        }

        $this->tableGateway->update($data, ['id' => $id]);
    }

    public function deleteAlbum($id)
    {
        $this->tableGateway->delete(['id' => (int) $id]);
    }
}