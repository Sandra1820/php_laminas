<?php

namespace Comment\Controller;

use Comment\Form\CommentForm;
use Comment\Model\Comment;
use Comment\Model\CommentTable;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Laminas\EventManager\EventManagerInterface;
use Laminas\Session;

class CommentController extends AbstractActionController
{

    private $table;

    public function __construct(CommentTable $table)
    {
        $this->table = $table;
    }

    public function indexAction()
    {
        $userSession = new Session\Container('user');
            
           
            $id = (int) $this->params()->fromRoute('id' , '0');
           
          
            return new ViewModel([
                //  'user' => $userSession->details,
                
                'cmddd'=> $this->table->getCommentss($id),
                // 'articleId' => $id
                
            ]);
    }

    public function addAction()
    {
        $id = (int) $this->params()->fromRoute('id' , '0');
            $form = new CommentForm();
            $form->get('album_id')->setValue($id);
            $form->get('submit')->setValue('Add');
    
            $request = $this->getRequest();
    
            if (! $request->isPost()) {
                return ['form' => $form];
            }
    
            $Comment = new Comment();
            $form->setInputFilter($Comment->getInputFilter());
            $form->setData($request->getPost());
    
            if (! $form->isValid()) {
                return ['form' => $form];
            }
    
            $Comment->exchangeArray($form->getData());
            $this->table->saveComment($Comment);
            return $this->redirect()->toRoute('album');
        }

        public function setEventManager(EventManagerInterface $events)
        {
            parent::setEventManager($events);
            
         $events->attach('dispatch', function ($e) {
           
                
                $userSession = new Session\Container('user');
                
                if ($userSession->details) {
                    $e->getViewModel()->setVariable('user', $userSession->details);
                }
        }, 100);
    
        }
}