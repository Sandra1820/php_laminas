<?php

namespace Comment\Model;

use Album\Model\AlbumTable;
use RuntimeException;
use Laminas\Db\TableGateway\TableGatewayInterface;
use Laminas\Session;
use Laminas\Db\sql\Select;
// use Album\Model\AlbumTable;
use Album\Model\Album;
use Laminas\Db\Sql\Where;
class CommentTable
{
    private $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll()
    {
        return $this->tableGateway->select();
    }
    public function getAll()
    {
        $userSession = new Session\Container('user');
        $userid= $userSession->details->getId();

        return $this->tableGateway->select(function(Select $select )use($userid){
            $select->join('users','comment.user_id = users.id',[])->where(['users.id'=>$userid]);
        });
    }
 
    protected $table = 'cmddd'; 
 
    public function fetchAlbumAndUserIdByCommentId($commentId)
    {
        $select = new Select($this->table);
        $select->columns(['id', 'user_id']); 
 
        $select->join( 'album', 'cmddd.album_id = album.id', ['album_id' => 'id'],  $select::JOIN_LEFT  );
 
        $select->join('users', 'cmddd.user_id = users.id',  ['username'], $select::JOIN_LEFT);
        
// $select->where([]);
 
//         $where = new Where();
// $where->equalTo('cmddd.id', $commentId);
 
//         $select->where($where);
 
        $rowset = $this->tableGateway->selectWith($select);
        return $rowset;
        // $row = $rowset->current();
 
        // if (!$row) {
        //     throw new \Exception("Comment with ID $commentId not found");
        // }
 
        // return [
        //     'album_id' => $row->album_id,
        //     'user_id'   => $row->userid,
        //     'username' => $row->username,
        //     'comment'=>$row->comment,
        // ];
    }
    public function getCommentss($id)
    {
        // $servicemanager = new ServiceManager();
        // $servicemanager->setService('config', require 'D:/xampp8.1/htdocs/Blog/config/autoload/local.php');

        // $dbAdapter = $servicemanager->get(Adapter::class);

        // $cmddd='cmddd';

        // $tableGateway = new TableGateway($cmddd,$dbAdapter);
        // $sql ="SELECT cmddd.album_id,users.username,cmddd.comment FROM cmddd
        // LEFT JOIN users ON users.id = cmddd.user_id
        // LEFT JOIN album ON cmddd.album_id= album.id";

        // $resultSet=$tableGateway->getAdapter()->query($sql,Adapter::QUERY_MODE_EXECUTE);

        // return $resultSet;



        $userSession = new Session\Container('user');
        $userid= $userSession->details->getId();
        
        $select = $this->tableGateway->getSql()->select()->where(['cmddd.album_id' => $id ]);

    //    $select->columns(['id','album_id','user_id','comment'])
    //    ->join('users','cmddd.user_id = users.id',['username'], Select::JOIN_INNER)
    //    ->join('album','cmddd.album_id = album.id',[], Select::JOIN_INNER)
    //    ->where(['cmddd.album_id' => $id ]);

     
      
       
       $resultSet= $this->tableGateway->selectWith($select);
   
        return $resultSet;

    }
    public function getComment($id)
    {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(['id' => $id]);
        $row = $rowset->current();
        if (! $row) {
            throw new RuntimeException(
                sprintf('Could not find row with identifier %d',$id)
            );
        }

        return $row;
    }

    public function saveComment(Comment $Comment)
    {
        $userSession = new Session\Container('user');
        $userid= $userSession->details->getId();
        // $album_id= new AlbumTable ();
        // $albumid=$album_id->fetchAll('id');
        
        $data = [
            'comment' => $Comment->comment,
            'user_id'=>$userid,
             'album_id' =>$Comment->album_id,
        ];

        $id = (int) $Comment->id;

        if ($id === 0) {
            $this->tableGateway->insert($data);
            return;
        }

        try {
            $this->getComment($id);
        } catch (RuntimeException $e) {
            throw new RuntimeException(sprintf('Cannot update Comment with identifier %d; does not exist',$id)
        );
        }

        $this->tableGateway->update($data, ['id' => $id]);
    }

    public function deleteComment($id)
    {
        $this->tableGateway->delete(['id' => (int) $id]);
    }
}