<?php



declare(strict_types=1);

namespace Application;

use Laminas\Router\Http\Literal;
use Laminas\Router\Http\Segment;
use Laminas\ServiceManager\Factory\InvokableFactory;



return [
'router' => [
    'routes' => [
            'home' => [
                'type'    => Literal::class,
                'options' => [
                    'route'    => '/',
                    'defaults' => [
                        'controller' => Controller\IndexController::class,
                        'action'     => 'index',
                    ],
                ],
            ],

            'register' => [
                'type' => Literal::class,
                'options' => [
                    'route' => '/register',
                    'defaults' => [
                        'controller' => Controller\RegisterController::class,
                        'action' => 'index',
                    ],
                ],
            ],
            'login' => [
                'type' => Segment::class,
                'options' => [
                    'route' => '/login[/:action]',
                    'defaults' => [
                        'controller' => Controller\LoginController::class,
                        'action' => 'index',
                    ],
                ],
            ],
            'user' => [
                'type' => Segment::class,
                'options' => [
                    'route' => '/album[/:action]',
                    'defaults' => [
                        'controller' => Controller\UserController::class,
                        'action' => 'index',
                    ],
                ],
            ],

            

        ],
    ],
    'controllers' => [
        'factories' => [
            Controller\IndexController::class => function($container) {
                return new Controller\IndexController( $container->get(Model\AlbumTable::class));
            },
            Controller\RegisterController::class => function($sm) {
                return new Controller\RegisterController(
                    $sm->get(Model\UsersTable::class),
                    $sm->get(\Utils\Security\Authentication::class),
                    $sm->get(\Utils\Security\Helper::class)
                );
            },
            Controller\LoginController::class => function($sm) {
		return new Controller\LoginController(
                    $sm->get(\Utils\Security\Authentication::class)
		);
            },
            Controller\UserController::class => InvokableFactory::class
         


        ],
    ],
    'view_manager' => [
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_path_stack' => [
            __DIR__ . '/../view',
            __DIR__ . '/../view/application/_shared'
        ],
        'base_path' => '',
        'base_url' => '/laminas_app/'
    ],
                    
    
];
