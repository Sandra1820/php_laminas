<?php

/**
 * @see       https://github.com/laminas/laminas-mvc-skeleton for the canonical source repository
 * @copyright https://github.com/laminas/laminas-mvc-skeleton/blob/master/COPYRIGHT.md
 * @license   https://github.com/laminas/laminas-mvc-skeleton/blob/master/LICENSE.md New BSD License
 */

declare(strict_types=1);

namespace Application;


use Laminas\Db\ResultSet\ResultSet;
use Laminas\Db\TableGateway\TableGateway;
use Application\Model\Rowset\User;
use Application\Model\UsersTable;
use Laminas\Db\Adapter\AdapterInterface;
use Application\Model\AlbumTable;
use Laminas\ServiceManager\Factory\InvokableFactory;
use Laminas\Session\SessionManager;
use Laminas\Session;




class Module
{
    public function getConfig(): array
    {
        return include __DIR__ . '/../config/module.config.php';
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'UsersTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Laminas\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();

                    //get base url from config
                    $config = $sm->get('Config');
                    $baseUrl = $config['view_manager']['base_url'];

                    //pass base url via cnstructor to the User class
                    $resultSetPrototype->setArrayObjectPrototype(new User($baseUrl));
                    return new TableGateway('users', $dbAdapter, null, $resultSetPrototype);
                },
                'Application\Model\UsersTable' => function ($sm) {
                    $tableGateway = $sm->get('UsersTableGateway');
                    $table = new UsersTable($tableGateway);

                    return $table;
                },
                Model\AlbumTable::class => function($container) {
                    $tableGateway = $container->get(Model\AlbumTableGateway::class);
                    return new Model\AlbumTable($tableGateway);
                },
                Model\AlbumTableGateway::class => function ($container) {
                    $dbAdapter = $container->get(AdapterInterface::class);
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Model\Album());
                    return new TableGateway('album', $dbAdapter, null, $resultSetPrototype);
                },

                \Utils\Security\Authentication::class => function ($sm) {
                    $auth = new \Utils\Security\Authentication(
                        $sm->get(\Laminas\Db\Adapter\Adapter::class),
                        $sm->get(\Utils\Security\Adapter::class)
                    );
                    return $auth;
                },
                \Utils\Security\Helper::class => InvokableFactory::class,

                SessionManager::class => function ($container) {
                    $config = $container->get('config');
                    $session = $config['session'];
                    $sessionConfig = new $session['config']['class']();
                    $sessionConfig->setOptions($session['config']['options']);
                    $sessionManager = new SessionManager(
                        $sessionConfig,
                        new $session['storage'](),
                        null
                    );
                    \Laminas\Session\Container::setDefaultManager($sessionManager);

                    return $sessionManager;
                },



            )
        );
    }

}