<?php

namespace Application\Form;

use Laminas\Form\Form;
use Laminas\Form\Element;


class BlogForm extends Form
{
    public function __construct($name = null)
    {
        parent::__construct($name);


        $this->add([
            'name' => 'title',
            'type' => Element\Text::class,
            'options' => [
                'label' => 'Title',
            ],
            'attributes' => [
                'required' => true,
            ],
        ]);


        $this->add([
            'name' => 'date',
            'type' => Element\Date::class,
            'options' => [
                'label' => 'Date',
            ],
            'attributes' => [
                'required' => true,
            ],
        ]);


        $this->add([
            'name' => 'image',
            'type' => Element\File::class,
            'options' => [
                'label' => 'Image',
            ],
            'attributes' => [
                'required' => true,
            ],
        ]);


        $this->add([
            'name' => 'content',
            'type' => Element\Textarea::class,
            'options' => [
                'label' => 'Content',
            ],
            'attributes' => [
                'required' => true,
            ],
        ]);


        $this->add([
            'name' => 'submit',
            'type' => Element\Submit::class,
            'attributes' => [
                'value' => 'Submit',
                'class' => 'btn btn-primary'
            ]
        ]);
        $this->setAttribute('method', 'POST');
     
    }
}