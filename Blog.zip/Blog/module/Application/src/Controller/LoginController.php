<?php

namespace Application\Controller;

use Application\Model;
use Application\Form;
use Laminas\Session;
use Laminas\Mvc\Controller\AbstractActionController;

class LoginController extends AbstractActionController
{
    protected $securityAuth;

    public function __construct($securityAuth)
    {
        $this->securityAuth = $securityAuth;
    }
    public function indexAction()
    {
        $form = new Form\UserLoginForm();

        if (!$this->getRequest()->isPost()) {
            return [
                'form' => $form
            ];
        }
        $form->setData($this->getRequest()->getPost());

        if (!$form->isValid()) {
            return [
                'form' => $form,
                'messages' => $form->getMessages()
            ];
        }
        $auth = $this->securityAuth->auth(
            $form->get($form::FIELDSET_LOGIN)->get('email')->getValue(),
            $form->get($form::FIELDSET_LOGIN)->get('password')->getValue()
        );
        // var_dump($auth);
        $identity = $this->securityAuth->getIdentityArray($auth);

        if ($identity) {
            $rowset = new Model\Rowset\User();
            $rowset->setRole('user');
            $rowset->exchangeArray($identity);
            $this->securityAuth->getStorage()->write($rowset);

            $sessionUser = new Session\Container('user');
            $sessionUser->details = $rowset;

            if($rowset -> id === 23){
                
                return $this->redirect()->toRoute('admin');
                
            }
          
            return $this->redirect()->toRoute('user');
          
        } else {
            $message = '<strong>Error</strong> Given email address or password is incorrect.';
            return [
                'form' => $form,
                'messages' => $message
            ];
        }
    }
    
    public function logoutAction()
    {
        $session = new Session\Container('user');
        $session->getManager()->destroy();
        $this->redirect()->toRoute('home');
    }
}
