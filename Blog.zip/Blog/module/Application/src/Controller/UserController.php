<?php

namespace Application\Controller;
use Application\Form\BlogForm;
use Laminas\Session;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\EventManager\EventManagerInterface;
use Laminas\View\Model\ViewModel;

class UserController extends AbstractActionController
{
    
    public function indexAction() {

        
        $userSession = new Session\Container('user');
        
       
        
        
         return [
             'user' => $userSession->details
         ];
    }
   
 
    public function setEventManager(EventManagerInterface $events)
    {
        parent::setEventManager($events);
        
	 $events->attach('dispatch', function ($e) {
       
            
            $userSession = new Session\Container('user');
            
            if ($userSession->details) {
                $e->getViewModel()->setVariable('user', $userSession->details);
            }
	}, 100);

    }
}

 