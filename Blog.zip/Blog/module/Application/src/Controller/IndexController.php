<?php


declare(strict_types=1);

namespace Application\Controller;
use Application\Model\Album;
use Application\Model\AlbumTable;
use Application\Form\AlbumForm;
use Laminas\View\Model\ViewModel;
use Laminas\Mvc\Controller\AbstractActionController;

class IndexController extends AbstractActionController
{
    // public function indexAction()
    // {
           
    //     return new ViewModel();
    // }
    private $table;

    public function __construct(AlbumTable $table)
    {
        $this->table = $table;
    }

    public function indexAction()
    {

        return new ViewModel([
            'albums' => $this->table->fetchAll(),
        ]);
    //    if($submit){
    //     return $this->redirect()->toRoute('album');
    //    }
    }


  

}
