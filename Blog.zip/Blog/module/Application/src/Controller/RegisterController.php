<?php

namespace Application\Controller;

use Application\Form;
use Application\Model;
use Application\Hydrator;
use Laminas\Mvc\Controller\AbstractActionController;

class RegisterController extends AbstractActionController {
    protected $usersModel;
    protected $securityAuth;
    protected $securityHelper;

    public function __construct($usersModel, $securityAuth, $securityHelper)
    {
        $this->usersModel = $usersModel;
        $this->securityAuth = $securityAuth;
        $this->securityHelper = $securityHelper;
    }

    public function indexAction()
    {
        $form = new Form\UserRegisterForm(
            'user_register',
            [
                'dbAdapter' => $this->usersModel->getTableGateway()->getAdapter(),
                //'baseUrl' => $this->baseUrl
            ]
        );
        $viewParams = [
            'userForm' => $form
        ];
        
        if ($this->getRequest()->isPost()) { 
            $form->setData($this->getRequest()->getPost());
            
            if ($form->isValid()) {
                $rowset = new Model\Rowset\User();
                $hydrator = new Hydrator\UserFormHydrator($this->securityHelper);
                $formData = $form->getData();
                $rowset->exchangeArray($hydrator->hydrate($form));

                //store to database
                $userId = $this->usersModel->save($rowset);
                $rowset->setId($userId);
                   
                    return $this->redirect()->toUrl('login');
                
            } else {
                $viewParams['messages'] = $form->getMessages();
            }
        }
        return $viewParams;
    }
}

